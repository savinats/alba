%Link Budget Coated
clear;
clc;
close all;

hv=3.73e-19;                                                                 % J at 532 of single photon
d=12e-03;                                                                    % ccr diameter
l=5.32e-07;                                                                  % wavelength
ro=0.78;                                                                     % reflectivity of Al coated
alt_alba=500000;                                                             % altitude 500km
N_bg_day = 1.4e08;                                                           % background noise sunlit clouds
N_bg_night = 1.4e03;                                                         % background noise at night 

data = readtable('GS_data.xlsx');
filename = 'coated.xlsx';
 
E_t = (data.Energy./1000)./(hv);                                             % mJ to J
n = data.n_q.*data.n_t.*data.n_r;                                            % efficiency
G_t = (8./(data.theta_D).^2).*exp((-2)*(data.theta_P./data.theta_D).^2);

ocs_peak = (ro*(d^4)*(pi^3))/(4*(l^2));
A_r = (pi.*(data.Aperture./2).^2);                                           % aperture to receiver area                                              
omega_r = (data.FOV./2).^2;                                                  % receiver solid angle FOV 

N_b_day = (data.n_q./hv).*N_bg_day.*(data.lambda_bp.*1E-09).*...
    omega_r.*A_r.*data.n_r.*(data.rangegate.*1E-09);                         % photons from noise (day)
N_b_night = (data.n_q./hv).*N_bg_night.*(data.lambda_bp.*1E-09).*...
    omega_r.*A_r.*data.n_r.*(data.rangegate.*1E-09);                         % photons from noise (night)

P_FA_day = 1-exp(-N_b_day);                                                  % probability of false alarm (day)
P_FA_night = 1-exp(-N_b_night);                                              % probability of false alarm (night)

step = 1;
Ph = zeros(42,height(data));
P_PD = zeros(42,height(data));
P_SD_day = zeros(42,height(data));
P_SD_night = zeros(42,height(data));


for i = 90:-1:45
    zen = deg2rad(90-i);                                                     % zenith angle and incidence angle
    R = height2range(alt_alba,data.Elevation,i);                             % slant range
    theta_ref = asin(sin(zen)/1.455);                                        % internal refracted angle
    mu = sqrt(1-(tan(theta_ref))^2); 
    eta_ocs = (2/pi)*(asin(mu)-(sqrt(2)*tan(theta_ref))*cos(zen));           % cross section reduction factor
    OCS = (eta_ocs^2)*ocs_peak;                                              % OCS for incidence angle
    rng = (1./(4.*pi.*R.^2)).^2;                                             % two way space loss
    T_c = exp(-0.14*(1.341*sec(zen))^2);                                     % one way cirrus loss
    T_a = exp(-0.25.*1.2.*sec(zen).*exp(-(data.Elevation./1000)./1.2));      % one way atmospheric loss
    Ph(step,:) = E_t.*n.*G_t.*A_r.*T_a.^2.*T_c^2.*OCS.*rng';                 % link equation
    N = Ph(:,:)+N_b_day';                                                    % total number of photoelectron (day)
    P_PD_night(step,:) = 1-exp(-Ph(step,:));                                 % probability of signal+noise detection (night)
    P_PD_day(step,:) = 1-exp(-N(step,:));                                    % probability of signal+noise detection (day)
    P_SD_day(step,:) = (1-P_FA_day').*P_PD_day(step,:);                      % probability of signal detection from noise (day)
    P_SD_night(step,:) = (1-P_FA_night').*P_PD_night(step,:);                % probability of signal detection from noise (night)
    step = step+1;    
end

for i = 44:-1:20
    zen = deg2rad(90-i);                                                     % zenith angle and incidence angle
    theta_inc = deg2rad(i);
    R = height2range(alt_alba,data.Elevation,i);                             % slant range
    theta_ref = asin(sin(theta_inc)/1.455);                                  % internal refracted angle
    mu = sqrt(1-(tan(theta_ref))^2); 
    eta_ocs = (2/pi)*(asin(mu)-(sqrt(2)*tan(theta_ref))*cos(theta_inc));     % cross section reduction factor
    OCS = (eta_ocs^2)*ocs_peak;                                              % OCS for incidence angle
    rng = (1./(4.*pi.*R.^2)).^2;                                             % two way space loss
    T_c = exp(-0.14*(1.341*sec(zen))^2);                                     % one way cirrus loss
    T_a = exp(-0.25.*1.2.*sec(zen).*exp(-(data.Elevation./1000)./1.2));      % one way atmospheric loss
    Ph(step,:) = E_t.*n.*G_t.*A_r.*T_a.^2.*T_c^2.*OCS.*rng';                 % link equation
    N = Ph(:,:)+N_b_day';                                                    % total number of photoelectron (day)
    P_PD_night(step,:) = 1-exp(-Ph(step,:));                                 % probability of signal+noise detection (night)
    P_PD_day(step,:) = 1-exp(-N(step,:));                                    % probability of signal+noise detection (day)
    P_SD_day(step,:) = (1-P_FA_day').*P_PD_day(step,:);                      % probability of signal detection from noise (day)
    P_SD_night(step,:) = (1-P_FA_night').*P_PD_night(step,:);                % probability of signal detection from noise (night)
    step = step+1;
end

var = data.Station';
Ph = array2table(Ph);
Ph.Properties.VariableNames = var;

P_SD_day = array2table(P_SD_day);
P_SD_day.Properties.VariableNames = var;

P_SD_night = array2table(P_SD_night);
P_SD_night.Properties.VariableNames = var;


 writetable(P_SD_night,filename,'Sheet','Detection_prob_night','Range','A1');
 writetable(P_SD_day,filename,'Sheet','Detection_prob_day','Range','A1');

