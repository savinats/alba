%Efficiencies 
clear;
clc;
close all;

% Load data from Excel
night = xlsread('MRR.xlsx',1); 
day = xlsread('MRR.xlsx',2);

% Extract degrees and parameter names
n_array= {'MATM', 'POT3', 'GRZL','GRSM','SFEL','WETL','ZIML','BORL','HERL','SISL','STL3','SHA2','KUN2','HRTL','HARL','BRAL','SJUL','AREL','JFNL','SEJL','BEIL','THTL','HA4T','MONL','GODL','YARL','KTZL','IRKL','BADL','ZELL','SVELL','BAIL','ARKL','RIGL','ALTL','MDVS','SIML'}; 
d_array= {'MATM', 'POT3', 'GRZL','GRSM','SFEL','WETL','ZIML','HERL','SHA2','KUN2','HRTL','BRAL','AREL','JFNL','SEJL','BEIL','HA4T','MONL','GODL','KTZL','IRKL','BADL','ZELL','SVELL','BAIL','ARKL','RIGL','ALTL','MDVS'};

figure;

% Plot for Night
for i = 2:size(night, 2)
    n_eff = night(:,i);
    degrees = 90-night(:,1);
    plot(degrees, n_eff,'DisplayName',n_array{i-1})
    hold on;
end

 ylim([0 1])
 yline(0.5, '--', 'LineWidth', 1.2, 'Color', 'black', 'DisplayName', 'Threshold');

hold off;

title('Efficiency of the MRR during Night');
xlabel('\theta inc');
ylabel('Efficiency');
legend('show');

%Plot for Day
for i=2:size(day, 2)
    degrees = 90-day(:,1);
    d_eff = day(:, i);
    plot(degrees, d_eff, 'DisplayName',d_array{i-1});
    hold on;
end

ylim([0 1])
yline(0.5, '--', 'LineWidth', 1.2, 'Color', 'black', 'DisplayName', 'Threshold');

hold off;

title('Efficiency of the MRR during Day');
xlabel('\theta inc');
ylabel('Efficiency');
legend('show');
