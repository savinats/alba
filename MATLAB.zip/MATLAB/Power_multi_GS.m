clear
clc
close all

data = readtable('GS_data.xlsx');

filename = 'Power_25.4_multi.xlsx';

lambda = 5.32E-07;                                                              % wavelenght
h = 500000;                                                                     % satellite altitude
CCR_diam = 25.4E-03;                                                            % CCr diameter


P_avg = (data.Energy.*1E-03).*data.RepetitionRate;                              % average laser power
duty_cycle = (data.PulseWidth.*1E-12).*data.RepetitionRate;                     % duty cycle
P_peak = P_avg./duty_cycle;                                                     % peak power

step = 1;
trasm_up = zeros(71,height(data));
trasm_down = zeros(71,height(data));
trasm_tot = zeros(71,height(data));

P_b = 1.48E08.*((data.FOV./2).^2).*pi.*((data.Aperture./2).^2).*...              % Power from noise
    (data.lambda_bp.*1E-09);  

P_b(1) = P_b(1).*0.01;                                                           % Matera attenuation filter

for i = 90:-1:20
    R = height2range(h,data.Elevation,i);                                        % slant range
    zen = deg2rad(90-i);                                                         % zenith angle 
    n_0_up = 0.2.*data.n_t.*10^(-(4.34*0.8*sec(zen))/10);
    n_0_down = 0.2.*data.n_r.*10^(-(4.34*0.8*sec(zen))/10);

    % Uplink beam diameter
    w_z_up = data.BeamDiameter.*sqrt(1+((R'.*lambda)./(pi.*(data.BeamDiameter).^2).^2));

    % Uplink transmittance
    trasm_up(step,:) = n_0_up.*(1-exp(-2.*CCR_diam^2./w_z_up.^2));
    
    % Downlink beam diameter
    w_z_down = CCR_diam*sqrt(1+((R'*lambda)./(pi*(CCR_diam)^2)^2));
    
    % Downlink transmittance
    trasm_down(step,:) = n_0_down.*(1-exp(-2.*data.Aperture.^2./w_z_down.^2));

    step = step+1;
end

trasm_tot = trasm_up.*trasm_down;

P_return_avg = P_avg'.*trasm_tot.*1E+9; % return avg power in nanowatts
P_return_peak = P_peak'.*trasm_tot;

SNR = 10*log10((P_return_avg.*1E-9)./(P_b'));

MIN = min(SNR(:,1))

MAX = max(SNR(:,1))

MEAN = mean(SNR(:,1))


var = data.Station';
trasm_up = array2table(trasm_up);
trasm_up.Properties.VariableNames = var;
trasm_down = array2table(trasm_down);
trasm_down.Properties.VariableNames = var;
trasm_tot = array2table(trasm_tot);
trasm_tot.Properties.VariableNames = var;
P_return_avg = array2table(P_return_avg);
P_return_avg.Properties.VariableNames = var;
P_return_peak = array2table(P_return_peak);
P_return_peak.Properties.VariableNames = var;
SNR = array2table(SNR);
SNR.Properties.VariableNames = var;



writetable(P_return_avg,filename,'Sheet','Power_avg_return','Range','B1');
writetable(SNR,filename,'Sheet','SNR','Range','B1');
writetable(trasm_tot,filename,'Sheet','Trasm_tot','Range','B1');
