clear
clc
close all

data = readtable('GS_data.xlsx'); 

lambda = 5.32E-07;                     % wavelenght
hv = 3.73E-19;                         % single photon energy
alt_alba = 500000;                     % stellite altitude (500 km)
CCR_diam = 12.7E-03;                   % CCR diameter
N_bg_day = 1.4E+08;                    % background noise sunlit clouds
N_bg_night = 1.4E03;                   % background noise at night 

filename = 'Link_25.4_multi_2CCR.xlsx';

OCS_peak = 0.78*(pi^3*(CCR_diam^4))/(4*(lambda^2));                                 % peak optical cross section

data.n_r(1) = data.n_r(1)*0.01;                                                     % matera attenuation filter
E_t = (data.Energy./1000)./(hv);                                                    % laser pulse energy
n = data.n_q.*data.n_t.*data.n_r;                                                   % efficiencies
G_t = (2./((data.theta_D./2).^2)).*exp((...
    data.theta_P./(data.theta_D./2)).^2);                                           % transmitter gain
A_r = (pi.*(data.Aperture./2).^2);                                                  % receiver area

omega_r = (data.FOV./2).^2;                                                         % receiver solid angle FOV 

N_b_day = (data.n_q./hv).*N_bg_day.*(data.lambda_bp.*1E-09).*...
    omega_r.*A_r.*data.n_r.*(data.rangeGate.*1E-09);                                % photons from noise (day)
N_b_night = (data.n_q./hv).*N_bg_night.*(data.lambda_bp.*1E-09).*...
    omega_r.*A_r.*data.n_r.*(data.rangeGate.*1E-09);                                % photons from noise (night)
P_FA_day = 1-exp(-N_b_day);                                                         % probability of false alarm (day)
P_FA_night = 1-exp(-N_b_night);                                                     % probability of false alarm (night)

step = 1;
Ph = zeros(71,height(data));
P_PD = zeros(71,height(data));
P_SD_day = zeros(71,height(data));
P_SD_night = zeros(71,height(data));


for i = 90:-1:45
    zen = deg2rad(90-i);                                                             % zenith angle and incidence angle
    R = height2range(alt_alba,data.Elevation,i);                                     % slant range
    theta_ref = asin(sin(zen)/1.455);                                                % internal refracted angle
    mu = sqrt(1-(tan(theta_ref))^2); 
    eta_ocs = (2/pi)*(asin(mu)-(sqrt(2)*tan(theta_ref))*cos(zen));                   % cross section reduction factor
    OCS = (eta_ocs^2)*OCS_peak;                                                      % OCS for incidence angle
    rng = (1./(4.*pi.*R.^2)).^2;                                                     % two way space loss
    T_c = exp(-0.14*(1.341*sec(zen))^2);                                             % one way cirrus loss
    T_a = exp(-0.25.*1.2.*sec(zen).*exp(-(data.Elevation./1000)./1.2));              % one way atmospheric loss
    Ph(step,:) = E_t.*n.*G_t.*A_r.*T_a.^2.*T_c^2.*OCS.*rng';                         % link equation
    N = Ph(:,:)+N_b_day';                                                            % total number of photoelectron (day)
    P_PD_night(step,:) = 1-exp(-Ph(step,:));                                         % probability of signal+noise detection (night)
    P_PD_day(step,:) = 1-exp(-N(step,:));                                            % probability of signal+noise detection (day)
    P_SD_day(step,:) = (1-P_FA_day').*P_PD_day(step,:);                              % probability of signal detection from noise (day)
    P_SD_night(step,:) = (1-P_FA_night').*P_PD_night(step,:);                        % probability of signal detection from noise (night)
    step = step+1;
end

for i = 44:-1:20
    zen = deg2rad(90-i);                                                             % zenith angle and incidence angle
    theta_inc = deg2rad(i);
    R = height2range(alt_alba,data.Elevation,i);                                     % slant range
    theta_ref = asin(sin(theta_inc)/1.455);                                          % internal refracted angle
    mu = sqrt(1-(tan(theta_ref))^2); 
    eta_ocs = (2/pi)*(asin(mu)-(sqrt(2)*tan(theta_ref))*cos(theta_inc));             % cross section reduction factor
    OCS = (eta_ocs^2)*OCS_peak;                                                      % OCS for incidence angle
    rng = (1./(4.*pi.*R.^2)).^2;                                                     % two way space loss
    T_c = exp(-0.14*(1.341*sec(zen))^2);                                             % one way cirrus loss
    T_a = exp(-0.25.*1.2.*sec(zen).*exp(-(data.Elevation./1000)./1.2));              % one way atmospheric loss
    Ph(step,:) = E_t.*n.*G_t.*A_r.*T_a.^2.*T_c^2.*OCS.*rng';                         % link equation
    N = Ph(:,:)+N_b_day';                                                            % total number of photoelectron (day)
    P_PD_night(step,:) = 1-exp(-Ph(step,:));                                         % probability of signal+noise detection (night)
    P_PD_day(step,:) = 1-exp(-N(step,:));                                            % probability of signal+noise detection (day)
    P_SD_day(step,:) = (1-P_FA_day').*P_PD_day(step,:);                              % probability of signal detection from noise (day)
    P_SD_night(step,:) = (1-P_FA_night').*P_PD_night(step,:);                        % probability of signal detection from noise (night)
    step = step+1;
end


var = data.Station';
Ph = array2table(Ph);
Ph.Properties.VariableNames = var;
P_SD_day = array2table(P_SD_day);
P_SD_day.Properties.VariableNames = var;
P_SD_night = array2table(P_SD_night);
P_SD_night.Properties.VariableNames = var;




% writetable(P_SD_night,filename,'Sheet','Detection_prob_night','Range','A1');
% writetable(P_SD_day,filename,'Sheet','Detection_prob_day','Range','A1');

